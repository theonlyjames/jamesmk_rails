/**
 * GO GO GADGET GOOGLE FONTS
 *
 * @author Jim Ramsden me@jimram.com
 * @copyright 2013 - Jim Ramsden
 */
WebFontConfig={google:{families:["Dosis:400,700:latin","Bitter:400,400italic,700:latin"]}},function(){var e=document.createElement("script");e.src=("https:"==document.location.protocol?"https":"http")+"://ajax.googleapis.com/ajax/libs/webfont/1/webfont.js",e.type="text/javascript",e.async="true";var t=document.getElementsByTagName("script")[0];t.parentNode.insertBefore(e,t)}();